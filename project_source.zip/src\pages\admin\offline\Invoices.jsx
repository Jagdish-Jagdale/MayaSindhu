import React, { useState, useEffect, useRef } from 'react';
import { 
  Plus, 
  Search, 
  FileText, 
  Loader2,
  Calendar,
  Filter,
  Download,
  User,
  Clock,
  Trash2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Eye,
  X
} from 'lucide-react';
import { db } from '../../../firebase';
import { 
  collection, 
  onSnapshot, 
  query, 
  orderBy,
  deleteDoc,
  doc
} from 'firebase/firestore';
import toast from 'react-hot-toast';
import InvoiceModal from '../../../components/admin/offline/InvoiceModal';

export default function Invoices() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  // Pagination & Sort state
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [rowsOpen, setRowsOpen] = useState(false);
  const rowsRef = useRef(null);
  const [sortConfig, setSortConfig] = useState({ key: 'createdAt', dir: 'desc' });

  const rowOptions = [5, 10, 20, 50];

  useEffect(() => {
    const handler = (e) => {
      if (rowsRef.current && !rowsRef.current.contains(e.target)) setRowsOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'storeOrders'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setInvoices(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    }, (error) => {
      console.error("Error fetching store orders:", error);
      toast.error("Failed to load invoice data.");
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this order?")) return;
    try {
      await deleteDoc(doc(db, 'storeOrders', id));
      toast.success("Order deleted successfully");
    } catch (error) {
      console.error("Error deleting order:", error);
      toast.error("Failed to delete order");
    }
  };

  const formatDate = (timestamp) => {
    if (!timestamp) return '---';
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  const handleSort = (key) => {
    setSortConfig(prev =>
      prev.key === key ? { key, dir: prev.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: 'asc' }
    );
  };

  const SortIcon = ({ colKey }) => {
    const isActive = sortConfig.key === colKey;
    const isDesc = isActive && sortConfig.dir === 'desc';
    return (
      <ChevronDown
        size={13}
        strokeWidth={3}
        className={`transition-all duration-200 ${isActive ? 'text-[#1BAFAF]' : 'text-gray-300'} ${isDesc ? 'rotate-180' : 'rotate-0'}`}
      />
    );
  };

  const filteredInvoices = (() => {
    let list = invoices.filter(i => 
      (i.customerName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (i.invoiceNumber || '').toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (sortConfig.key) {
      list = [...list].sort((a, b) => {
        let aVal = a[sortConfig.key] || '';
        let bVal = b[sortConfig.key] || '';

        if (sortConfig.key === 'createdAt') {
          if (aVal?.toDate) aVal = aVal.toDate();
          if (bVal?.toDate) bVal = bVal.toDate();
        } else if (sortConfig.key === 'total') {
          aVal = Number(aVal) || 0;
          bVal = Number(bVal) || 0;
        }

        if (aVal < bVal) return sortConfig.dir === 'asc' ? -1 : 1;
        if (aVal > bVal) return sortConfig.dir === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return list;
  })();

  const totalRecords = filteredInvoices.length;
  const totalPages = Math.ceil(totalRecords / rowsPerPage) || 1;
  const startIndex = (currentPage - 1) * rowsPerPage;
  const currentInvoices = filteredInvoices.slice(startIndex, startIndex + rowsPerPage);

  if (loading) {
    return (
      <div className="h-[70vh] flex flex-col items-center justify-center gap-4">
        <Loader2 className="w-10 h-10 animate-spin text-[#1BAFAF]" />
        <p className="text-[14px] font-medium text-gray-400">Loading invoice records...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      
      {/* Header Section */}
      <div className="space-y-2 py-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-[22px] font-semibold text-gray-900 tracking-tight">Invoices</h1>
            <p className="text-[12px] text-gray-400 font-medium tracking-tight">Manage and track customer invoices</p>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-widest">
               TOTAL RECORDS: {totalRecords}
            </span>
          </div>
        </div>
        <hr className="border-gray-100" />
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-4 bg-white p-2 rounded-2xl border border-gray-100 shadow-sm">
         <div className="relative flex-1 group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-300 group-focus-within:text-[#1BAFAF] transition-colors" />
            <input 
               type="text" 
               placeholder="Search by invoice number or customer..."
               value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full bg-gray-50 border-none py-2.5 pl-11 pr-4 text-[13px] rounded-xl outline-none focus:bg-white transition-all font-medium"
            />
         </div>
         <div className="flex items-center gap-2">
            <button className="p-2.5 text-gray-400 hover:text-gray-900 hover:bg-gray-50 rounded-xl transition-all"><Calendar size={18} /></button>
            <button className="p-2.5 text-gray-400 hover:text-gray-900 hover:bg-gray-50 rounded-xl transition-all"><Filter size={18} /></button>
            <div className="h-6 w-[1px] bg-gray-100 mx-1" />
            <div className="relative" ref={rowsRef}>
              <button
                onClick={() => setRowsOpen(prev => !prev)}
                className="flex items-center gap-2 px-3 py-1.5 text-[12px] font-semibold text-gray-500 hover:text-gray-900 transition-colors"
              >
                Rows: <span className="text-[#1BAFAF]">{rowsPerPage}</span>
                <ChevronDown size={12} className={`transition-transform duration-200 ${rowsOpen ? 'rotate-180' : ''}`} />
              </button>
              {rowsOpen && (
                <div className="absolute right-0 top-full mt-2 w-24 bg-white border border-gray-100 rounded-xl shadow-lg z-50 py-1 overflow-hidden">
                  {rowOptions.map(opt => (
                    <button
                      key={opt}
                      onClick={() => { 
                        setRowsPerPage(opt); 
                        setCurrentPage(1);
                        setRowsOpen(false); 
                      }}
                      className={`w-full text-left px-3 py-2 text-[13px] transition-colors ${
                        rowsPerPage === opt ? 'text-[#1BAFAF] font-semibold bg-[#1BAFAF]/5' : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      {opt} rows
                    </button>
                  ))}
                </div>
              )}
            </div>
         </div>
      </div>

      {/* Invoices Table */}
      <div className="space-y-3">
         <div className="bg-white rounded-[20px] border border-gray-100 shadow-sm overflow-x-auto custom-scrollbar">
            <table className="w-full text-left border-collapse">
               <thead>
                  <tr className="border-b border-gray-50 bg-white">
                     <th className="px-6 py-4 text-left text-[14px] font-bold text-[#1BAFAF]">Sr No</th>
                     <th className="px-6 py-4 text-left text-[14px] font-bold text-[#1BAFAF]">
                       <button onClick={() => handleSort('invoiceNumber')} className="flex items-center gap-1 hover:opacity-75 transition-opacity">
                         Invoice ID <SortIcon colKey="invoiceNumber" />
                       </button>
                     </th>
                     <th className="px-6 py-4 text-left text-[14px] font-bold text-[#1BAFAF]">
                       <button onClick={() => handleSort('customerName')} className="flex items-center gap-1 hover:opacity-75 transition-opacity">
                         Customer <SortIcon colKey="customerName" />
                       </button>
                     </th>
                     <th className="px-6 py-4 text-left text-[14px] font-bold text-[#1BAFAF]">
                       <button onClick={() => handleSort('createdAt')} className="flex items-center gap-1 hover:opacity-75 transition-opacity">
                         Date <SortIcon colKey="createdAt" />
                       </button>
                     </th>
                     <th className="px-6 py-4 text-left text-[14px] font-bold text-[#1BAFAF]">
                       <button onClick={() => handleSort('total')} className="flex items-center gap-1 hover:opacity-75 transition-opacity">
                         Amount <SortIcon colKey="total" />
                       </button>
                     </th>
                     <th className="px-6 py-4 text-left text-[14px] font-bold text-[#1BAFAF]">
                       <button onClick={() => handleSort('status')} className="flex items-center gap-1 hover:opacity-75 transition-opacity">
                         Status <SortIcon colKey="status" />
                       </button>
                     </th>
                     <th className="px-6 py-4 text-center text-[14px] font-bold text-[#1BAFAF]">Preview</th>
                     <th className="px-6 py-4 text-center text-[14px] font-bold text-[#1BAFAF]">Actions</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-gray-50/50">
                  {currentInvoices.length > 0 ? currentInvoices.map((invoice, index) => (
                    <tr key={invoice.id} className="hover:bg-gray-50 group transition-colors">
                       <td className="px-6 py-4 whitespace-nowrap text-[14px] text-gray-400 font-medium">
                          {String(startIndex + index + 1).padStart(2, '0')}
                       </td>
                       <td className="px-6 py-4 min-w-[150px]">
                          <span className="text-[14px] font-bold text-gray-900 uppercase">
                            {invoice.invoiceNumber || invoice.saleOrderNumber || `#${invoice.id.slice(-6)}`}
                          </span>
                       </td>
                       <td className="px-6 py-4">
                          <span className="text-[14px] text-gray-500 font-medium">{invoice.customerName || 'Customer'}</span>
                       </td>
                       <td className="px-6 py-4 whitespace-nowrap text-[14px] text-gray-500 font-medium">
                          {invoice.invoiceDate || invoice.saleOrderDate || formatDate(invoice.createdAt)}
                       </td>
                       <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-[14px] text-gray-500 font-medium">₹{(invoice.total || 0).toFixed(2)}</span>
                       </td>
                       <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg ${
                            (invoice.status || 'Confirmed').toLowerCase() === 'paid' || (invoice.status || 'Confirmed').toLowerCase() === 'confirmed' ? 'text-[#1BAFAF] bg-[#eaf6f6]' :
                            'text-amber-500 bg-amber-50'
                          }`}>
                            {invoice.status || 'Confirmed'}
                          </span>
                       </td>
                       <td className="px-6 py-4 text-center">
                          <button 
                            onClick={() => {
                              setSelectedInvoice(invoice);
                              setIsPreviewOpen(true);
                            }}
                            className="w-8 h-8 inline-flex items-center justify-center text-gray-400 hover:text-[#1BAFAF] hover:bg-[#1BAFAF]/5 rounded-lg transition-all active:scale-90"
                          >
                            <Eye size={16} strokeWidth={2.5} />
                          </button>
                       </td>
                       <td className="px-6 py-4 text-center">
                         <div className="flex items-center justify-center gap-2">
                           <button 
                             onClick={() => handleDelete(invoice.id)}
                             className="w-8 h-8 flex items-center justify-center text-red-600 hover:bg-red-50 rounded-lg transition-all active:scale-90"
                           >
                             <Trash2 size={14} strokeWidth={2.5} />
                           </button>
                         </div>
                       </td>
                    </tr>
                  )) : (
                    <tr>
                       <td colSpan="8" className="py-20 text-center">
                          <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-200">
                             <FileText size={32} />
                          </div>
                          <p className="text-[14px] font-bold text-gray-400 uppercase tracking-widest">No Invoices found</p>
                       </td>
                    </tr>
                  )}
               </tbody>
            </table>
         </div>
         
         {/* Pagination Footer */}
         <div className="flex items-center justify-end px-2 pt-1">
            <div className="flex items-center gap-2">
               <button 
                 onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
                 disabled={currentPage === 1}
                 className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-[#1BAFAF] hover:bg-[#1BAFAF]/5 transition-all disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-gray-400"
               >
                 <ChevronLeft size={16} strokeWidth={2.5} />
               </button>
               <span className="text-[12px] font-semibold text-gray-400">
                  Page {currentPage} of {totalPages}
               </span>
               <button 
                 onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
                 disabled={currentPage === totalPages}
                 className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-[#1BAFAF] hover:bg-[#1BAFAF]/5 transition-all disabled:opacity-30 disabled:hover:bg-transparent disabled:hover:text-gray-400"
               >
                 <ChevronRight size={16} strokeWidth={2.5} />
               </button>
            </div>
         </div>
      </div>

      <InvoiceModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />

      {/* View Preview Modal */}
      {isPreviewOpen && selectedInvoice && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div 
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            onClick={() => setIsPreviewOpen(false)}
          />
          <div className="relative w-full max-w-2xl bg-white rounded-[32px] shadow-2xl overflow-hidden max-h-[85vh] flex flex-col animate-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="px-8 py-6 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-gray-50 to-white flex-shrink-0">
              <div>
                <h2 className="text-[20px] font-bold text-gray-900 tracking-tight">Invoice Details</h2>
                <p className="text-[12px] text-gray-400 font-medium">Record Information</p>
              </div>
              <button 
                onClick={() => setIsPreviewOpen(false)}
                className="w-10 h-10 flex items-center justify-center rounded-2xl text-gray-400 hover:bg-gray-100 hover:text-gray-900 transition-all"
              >
                <X size={20} />
              </button>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto p-8 space-y-6 custom-scrollbar text-[14px]">
              {/* Summary Info */}
              <div className="grid grid-cols-2 gap-6 bg-gray-50/50 p-6 rounded-2xl border border-gray-100">
                <div className="space-y-1">
                  <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Invoice ID</p>
                  <p className="font-bold text-gray-900 uppercase">{selectedInvoice.invoiceNumber || selectedInvoice.saleOrderNumber || '---'}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Status</p>
                  <span className={`inline-block text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg ${
                    (selectedInvoice.status || 'Confirmed').toLowerCase() === 'paid' || (selectedInvoice.status || 'Confirmed').toLowerCase() === 'confirmed' ? 'text-[#1BAFAF] bg-[#eaf6f6]' :
                    'text-amber-500 bg-amber-50'
                  }`}>
                    {selectedInvoice.status || 'Confirmed'}
                  </span>
                </div>
                <div className="space-y-1">
                  <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Customer Name</p>
                  <p className="font-bold text-gray-700">{selectedInvoice.customerName || '---'}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Date</p>
                  <p className="font-bold text-gray-700">{selectedInvoice.invoiceDate || selectedInvoice.saleOrderDate || formatDate(selectedInvoice.createdAt)}</p>
                </div>
              </div>

              {/* Items Table */}
              <div className="space-y-3">
                <h3 className="text-[12px] font-bold text-gray-400 uppercase tracking-wider">Items Breakdown</h3>
                <div className="border border-gray-100 rounded-2xl overflow-hidden">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="bg-gray-50 text-[11px] font-bold text-gray-400 uppercase tracking-wider border-b border-gray-100">
                        <th className="px-4 py-3">Item Details</th>
                        <th className="px-4 py-3 text-center w-20">Qty</th>
                        <th className="px-4 py-3 text-right w-24">Rate</th>
                        <th className="px-4 py-3 text-right w-24">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {selectedInvoice.items && selectedInvoice.items.length > 0 ? (
                        selectedInvoice.items.map((item, index) => (
                          <tr key={index} className="text-gray-700 font-medium">
                            <td className="px-4 py-3">{item.name || '---'}</td>
                            <td className="px-4 py-3 text-center font-bold text-gray-900">{item.quantity || 0}</td>
                            <td className="px-4 py-3 text-right">₹{(item.rate || 0).toFixed(2)}</td>
                            <td className="px-4 py-3 text-right font-bold text-gray-900">₹{(item.amount || 0).toFixed(2)}</td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="4" className="px-4 py-8 text-center text-gray-400">No items found</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Totals Section */}
              <div className="border-t border-gray-100 pt-6 space-y-3 max-w-sm ml-auto">
                <div className="flex justify-between text-gray-500 font-medium">
                  <span>Sub Total</span>
                  <span className="text-gray-900">₹{(selectedInvoice.subTotal || 0).toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-500 font-medium">
                  <span>Tax (GST)</span>
                  <span className="text-gray-900">{selectedInvoice.tax || 0}%</span>
                </div>
                <div className="flex justify-between text-gray-500 font-medium">
                  <span>Adjustment</span>
                  <span className="text-gray-900">₹{(selectedInvoice.adjustment || 0).toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center text-base font-black border-t border-dashed border-gray-200 pt-3">
                  <span className="text-gray-900">Total ( ₹ )</span>
                  <span className="text-[#1BAFAF]">₹{(selectedInvoice.total || 0).toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-8 py-5 border-t border-gray-100 flex justify-end bg-gray-50 flex-shrink-0">
              <button 
                onClick={() => setIsPreviewOpen(false)}
                className="px-8 py-2.5 bg-[#1BAFAF] text-white rounded-xl text-[13px] font-bold hover:bg-[#158e8e] transition-all"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
